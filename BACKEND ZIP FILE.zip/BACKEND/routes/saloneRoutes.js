const express = require("express");
const router = express.Router();
const {
  createSalon,
  getSalons,
} = require("../controllers/salonController");

router.post("/", createSalon);
router.get("/", getSalons);

module.exports = router;